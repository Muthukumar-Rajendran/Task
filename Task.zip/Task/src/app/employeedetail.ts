export class Employeedetail {
    id?:any;
    Employeeid:any;
    Name:string;
    Skills:string;
    Email:string;
    photo:string;

}
