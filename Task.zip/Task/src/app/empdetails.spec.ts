import { Empdetails } from './empdetails';

describe('Empdetails', () => {
  it('should create an instance', () => {
    expect(new Empdetails()).toBeTruthy();
  });
});
