import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { Empdetails } from './empdetails';
import { Employeedetail } from './employeedetail';

@Injectable({
  providedIn: 'root'
})
export class EmployeedetailsService {
  private readonly url1:string="http://localhost:3000/Employeedetail"
  constructor(private http:HttpClient) { }
  logi() :Observable<Empdetails[]>
  {
   return this.http.get<any>(' http://localhost:3000/Empdetails');
  }
  empdetail(): Observable<any[]>{
    return this.http.get<any>('http://localhost:3000/Employeedetail');
  }
  create(form :Employeedetail):Observable<Employeedetail>
  {
    return this.http.post<Employeedetail>( this.url1,form);
  }
  deletee(id:any):Observable<Employeedetail>
  {
    return this.http.delete<Employeedetail>(this.url1 + "/" + id)
  }
  update(form :Employeedetail):Observable<void>
  {
    return this.http.put<void>( `${this.url1}/${form.id}`,form);
  }
}
