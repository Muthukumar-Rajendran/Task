import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeedetailsService } from '../employeedetails.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
users: string;
namee:string;
pwd:string;
b:any=[];
userstatus:string='notlogged'
status:string='';
  constructor(private empservice:EmployeedetailsService, private routes: Router) {
    this.empservice.logi().subscribe((dataa)=>{
      console.warn(dataa);
        this.b=dataa
    })
   }

  ngOnInit(): void {
  }
  
  logindetaill(){

    if(this.b.find(m=> m.username == this.namee && m.password == this.pwd))
    {
          this.status="Authenticated user";
        
           this.routes.navigate(['emp']);
           this.userstatus='loggedin'
           location.reload();
           localStorage.setItem('b',this.userstatus)
           localStorage.setItem('idd',JSON.stringify(this.b.find(res=>{
            return res.username.match(this.namee) && res.password.match(this.pwd);
          })))
        

         }
         else
        {
           this.status="Not Authenticated user";
           console.log(this.pwd)
          
           this.userstatus='notloggedin'
           localStorage.setItem('b',this.userstatus)

         }
  }
  loggedin():boolean{
    var status = localStorage.getItem("b");
 

    if(status == 'loggedin')
    {
      return true;
    }

    else
    {
      return false;
    }
  }


}
