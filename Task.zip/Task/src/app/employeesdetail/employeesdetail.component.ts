import { Component, OnInit,ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Employeedetail } from '../employeedetail';
import { EmployeedetailsService } from '../employeedetails.service';

@Component({
  selector: 'app-employeesdetail',
  templateUrl: './employeesdetail.component.html',
  styleUrls: ['./employeesdetail.component.css']
})
export class EmployeesdetailComponent implements OnInit {
  Employeelist: Employeedetail[];
  namee:string;
  idd:string;
  skill:string;

  
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns: String[]= ['id','Name','Skills','Email','Employeeid',"options"];
  dataSource: MatTableDataSource<Employeedetail>
  dataa:any;
  constructor(public employeeservice:EmployeedetailsService, public routes:Router) { }

  ngOnInit(): void {
    this.getMyEmployees();
  }
    getMyEmployees(): void
  {
    this.employeeservice.empdetail().subscribe(s=>
      {this.Employeelist=s;
        this.dataSource = new MatTableDataSource<Employeedetail>(this.Employeelist);
        console.log(this.dataSource);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
  })}
  Deleteemployee(data:Employeedetail):void
  {
    const confirm =window.confirm("Are you Sure want to delete?")
    if(confirm){
    this.employeeservice.deletee(data.id).subscribe(res=>{
      console.log(res);
      this.getMyEmployees();
 
    })}
  }
 searchname(){
   console.log(this.namee);
   this.dataa=this.Employeelist.filter(res=>{
     return res.Name.toLowerCase().match(this.namee.toLowerCase()); 
   })
   
   this.dataSource =this.dataa;
   if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  } }

  searchid(){
    console.log(this.idd);
    this.dataa=this.Employeelist.filter(res=>{
      return res.Employeeid==this.idd
    })
    
    this.dataSource =this.dataa;
    if (this.dataSource.paginator) {
     this.dataSource.paginator.firstPage();
   } }
   searchskills(){
    console.log(this.skill);
    this.dataa=this.Employeelist.filter(res=>{
      return res.Skills.toLowerCase().match(this.skill.toLowerCase()); 
    })
    
    this.dataSource =this.dataa;
    if (this.dataSource.paginator) {
     this.dataSource.paginator.firstPage();
   } }
 applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  


  public highlightSelectedRow(row): void
  {
      this.routes.navigate(['details', row.id ]);
  }
  public update(item):void
{console.log(item)
  this.routes.navigate(['update'])
 localStorage.setItem('edit',JSON.stringify(item))
  
}


}
