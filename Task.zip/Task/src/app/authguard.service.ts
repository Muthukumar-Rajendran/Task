import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate{
  canActivate(route: import("@angular/router").ActivatedRouteSnapshot): boolean {
 
    var a = localStorage.getItem('b');
    console.log(a);
 
    console.log(status);

    if(a == 'loggedin')
    {
      return true;
    }

    else
    {
      return false;
    }

  }


  constructor() { }
}
