export class Empdetails {
    username:string;
    password:string;
    photo:string;
    
}
